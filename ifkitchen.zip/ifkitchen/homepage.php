<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="stylesheet" href="styles.css">
        <meta name = "viewport" content = "width = device-widt, initial-scale = 1">
    </head>
    <body>
    <?php include('navbar.php');?>

        <center>
        <tr><center>
        <th colspan="2"><h2></h2></th></center>
        </tr>
            <div>
                 <td align="center" ><img src="1.png" width="450" height="200">
                <h2  size ="40" face= "IFKITCHEN" align="center">Welcome!</h2>
                <h3  size ="40" face= "IFKITCHEN" align="center"> The kitchen is the heart of any home. It’s where you gather
                     with loved ones and create home-cooked meals to feed your family. That’s why a dysfunctional, outdated 
                     kitchen simply won’t work. At IfKitchen, we want you to be excited about spending time in your kitchen, 
                     so we, at IfKitchen work with you directly to design and build the kitchen of your dreams.
                </h3>
            </center>
            </div>
    </body>
    </html>